# This file is part of tryton_synchronisation.  The COPYRIGHT file at the top
# level of this repository contains the full copyright notices and license
# terms.
import xmlrpclib
from itertools import groupby

from celery import Celery, group
from celery_tryton import TrytonTask

from trytond.config import CONFIG
from trytond.pool import Pool
from trytond.transaction import Transaction

celery = Celery('synchronisation')
batchlen = 1000


def get_xmlrpc_proxy():
    url = CONFIG['synchronisation_url']
    context = {
        'synchronisation_id': int(CONFIG['synchronisation_id']),
        }
    return xmlrpclib.ServerProxy(url, allow_none=1), context


def get_to_synchronise():
    from tryton_synchronisation import SyncMixin
    pool = Pool()
    return (Model for name, Model in pool.iterobject()
        if issubclass(Model, SyncMixin))


@celery.task()
def synchronise():
    group(synchronise_push_all.s(),
        synchronise_pull_all.s(),
        synchronise_new.s())()


@celery.task(base=TrytonTask)
def synchronise_push_all():
    to_synchronise = get_to_synchronise()

    with Transaction().set_context(active_test=False):
        for Model in to_synchronise:
            records = Model.to_synchronise_push()
            group(synchronise_push.s(Model.__name__, [r.id for _, r in l])
                for _, l in groupby(enumerate(records),
                    lambda i: i[0] // batchlen))()


@celery.task(base=TrytonTask)
def synchronise_push(model, ids):
    pool = Pool()
    Model = pool.get(model)
    records = Model.browse(ids)
    proxy, context = get_xmlrpc_proxy()

    synchronised, stamp = getattr(proxy.model, model).synchronise(
        [r.get_wire_value() for r in records], context)
    Model.set_synchronised(synchronised, stamp)


@celery.task(base=TrytonTask)
def synchronise_pull_all():
    to_synchronise = get_to_synchronise()

    with Transaction().set_context(active_test=False):
        for Model in to_synchronise:
            records = Model.to_synchronise_pull()
            group(synchronise_pull.s(Model.__name__, [r.id for _, r in l])
                for _, l in groupby(enumerate(records),
                    lambda i: i[0] // batchlen))()


@celery.task(base=TrytonTask)
def synchronise_pull(model, ids):
    pool = Pool()
    Model = pool.get(model)
    records = Model.browse(ids)
    proxy, context = get_xmlrpc_proxy()

    to_synchronise = getattr(proxy.model, model).get_to_synchronise(
        [r.get_etag() for r in records], context)
    Model.synchronise(to_synchronise)


@celery.task(base=TrytonTask)
def synchronise_new():
    to_synchronise = get_to_synchronise()
    proxy, context = get_xmlrpc_proxy()

    for Model in to_synchronise:
        model = Model.__name__
        to_synchronise = getattr(proxy.model, model
            ).get_to_synchronise(context)
        Model.synchronise(to_synchronise)
