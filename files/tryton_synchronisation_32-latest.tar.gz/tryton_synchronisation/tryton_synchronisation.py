# This file is part of tryton_synchronisation.  The COPYRIGHT file at the top
# level of this repository contains the full copyright notices and license
# terms.
import uuid
import xmlrpclib
import datetime

import bitstring
from sql import Query, Expression
from sql.operators import BAnd

from trytond import backend
from trytond.rpc import RPC
from trytond.config import CONFIG
from trytond.model import ModelStorage, fields
from trytond.model.fields import Field, SQLType, SQL_OPERATORS
from trytond.transaction import Transaction
from trytond.protocols.jsonrpc import JSONDecoder, JSONEncoder
from trytond.protocols.xmlrpc import XMLRPCDecoder
from trytond.exceptions import UserError
from trytond.pool import Pool

__all__ = ['UUID', 'SyncMixin', 'SyncUUIDMixin']


if CONFIG['db_type'] == 'postgresql':
    import psycopg2.extras
    from psycopg2 import extensions
    psycopg2.extras.register_uuid()

    def adapt_bits(bits):
        """psycopg2 adapter function for ``bitstring.BitArray``.

        Encode SQL parameters from ``bitstring.BitArray`` instances to SQL
        strings.
        """
        if bits.length % 4 == 0:
            return extensions.AsIs("X'%s'" % bits.hex)
        return extensions.AsIs("B'%s'" % bits.bin)

    def cast_bits(value, cur):
        """psycopg2 caster for bit strings.

        Turns query results from the database into ``bitstring.BitArray``
        instances.
        """
        if value is None:
            return None
        return bitstring.BitArray(bin=value)

    extensions.register_adapter(bitstring.BitArray, adapt_bits)

    # Must ensure the timezone is set to start a transaction
    # Remove timezone to be 3.2 compatible
    #CONFIG.set_timezone()

    Database = backend.get('Database')
    database = Database().connect()
    cursor = database.cursor()
    cursor.execute("SELECT NULL::VARBIT")
    varbit_oid = cursor.description[0].type_code
    cursor.commit()
    cursor.close()
    bit_caster = extensions.new_type((varbit_oid,), 'VARBIT', cast_bits)
    extensions.register_type(bit_caster)


def register_rpc_types():
    uuid2wire = lambda o: {
        '__class__': 'uuid',
        'urn': o.urn,
        }
    JSONEncoder.register(uuid.UUID, uuid2wire)
    xmlrpclib.Marshaller.dispatch[uuid.UUID] = \
        lambda self, value, write: self.dump_struct(uuid2wire(value), write)

    wire2uuid = lambda dct: uuid.UUID(dct['urn'])
    JSONDecoder.register('uuid', wire2uuid)
    XMLRPCDecoder.register('uuid', wire2uuid)

    bitstr2wire = lambda o: {
        '__class__': 'bitstring',
        'bin': o.bin,
        }
    JSONEncoder.register(bitstring.BitArray, bitstr2wire)
    xmlrpclib.Marshaller.dispatch[bitstring.BitArray] = \
        lambda self, value, write: self.dump_struct(bitstr2wire(value), write)

    wire2bitstr = lambda dct: bitstring.BitArray(bin=dct['bin'])
    JSONDecoder.register('bitstring', wire2bitstr)
    XMLRPCDecoder.register('bitstring', wire2bitstr)

register_rpc_types()


class UUID(Field):
    'Define a UUID field (``UUID``)'
    _type = 'uuid'

    def sql_type(self):
        db_type = CONFIG['db_type']
        if db_type == 'postgresql':
            return SQLType('UUID', 'UUID')
        elif db_type == 'mysql':
            return SQLType('CHAR', 'VARCHAR(32)')
        return SQLType('VARCHAR', 'VARCHAR')

    def sql_format(self, value):
        db_type = CONFIG['db_type']
        if isinstance(value, (Query, Expression)):
            return value
        if value is None:
            return value
        assert isinstance(value, uuid.UUID)
        if db_type == 'postgresql':
            return value
        else:
            return value.hex

    def get(self, ids, model, name, values=None):
        result = dict.fromkeys(ids)
        for value in values or []:
            if value[name] and not isinstance(value[name], uuid.UUID):
                result[value['id']] = uuid.UUID(value[name])
            else:
                result[value['id']] = value[name]
        return result


bitstring_len = 128
if CONFIG.get('synchronisation_id', None):
    assert bitstring_len > int(CONFIG['synchronisation_id'])


class BitString(Field):
    'Define a BitString field (``VARBIT``)'
    _type = 'varbit'

    def sql_type(self):
        db_type = CONFIG['db_type']
        if db_type == 'postgresql':
            return SQLType('VARBIT', 'VARBIT')
        elif db_type == 'mysql':
            return SQLType('UNSIGNED INTEGER', 'BIGINT')
        return SQLType('INTEGER', 'INTEGER')

    def sql_format(self, value):
        db_type = CONFIG['db_type']
        if isinstance(value, (Query, Expression)):
            return value
        if value is None:
            return value
        assert isinstance(value, bitstring.BitArray)
        if db_type == 'postgresql':
            return value
        else:
            return value.uint

    def get(self, ids, model, name, values=None):
        result = dict.fromkeys(ids)
        for value in values or []:
            if value[name] and not isinstance(value[name], bitstring.BitArray):
                result[value['id']] = bitstring.BitArray(uint=value[name],
                    length=bitstring_len)  # TODO add size attribute
            else:
                result[value['id']] = value[name]
        return result


class SynchronisationError(Exception):
    pass


class InexistantTarget(SynchronisationError):

    def __init__(self, target, id_):
        self.target = target
        self.id_ = id_

    def __str__(self):
        return 'Target "%s" has not record identified by "%s"' % (self.target,
            self.id_)


class SyncMixin(ModelStorage):
    'Adds synchronisation support'

    unique_id_column = None
    last_synchronisation = fields.Timestamp('Last Synchronisation')
    synchronised_instances = BitString('Synchronised Instances', required=True)
    synchronised = fields.Function(fields.Boolean('Synchronised'),
        'get_synchronised', searcher='search_synchronised')
    active = fields.Boolean('Active')

    @classmethod
    def __setup__(cls):
        super(SyncMixin, cls).__setup__()
        cls.__rpc__.update({
                'synchronise': RPC(readonly=False),
                'get_to_synchronise': RPC(readonly=True),
                })

    @staticmethod
    def default_synchronised_instances():
        id_ = int(CONFIG['synchronisation_id'])
        value = bitstring.BitArray(length=bitstring_len)
        value.set(1, bitstring_len - 1 - id_)
        return value

    def get_synchronised(self, name):
        context = Transaction().context
        if 'synchronisation_id' not in context:
            return
        id_ = context['synchronisation_id']
        instance = bitstring.BitArray(length=bitstring_len)
        instance.set(1, bitstring_len - 1 - id_)
        instances = self.synchronised_instances
        return bool(instances & instance)

    @classmethod
    def search_synchronised(cls, name, domain):
        context = Transaction().context
        if 'synchronisation_id' not in context:
            return [('id', '=', -1)]

        table = cls.__table__()

        name, operator, value = domain
        Operator = SQL_OPERATORS[operator]

        id_ = context['synchronisation_id']
        instance = bitstring.BitArray(length=bitstring_len)
        instance.set(1, bitstring_len - 1 - id_)
        bitnull = bitstring.BitArray(length=bitstring_len)

        # Must compare to a null bit
        # because PostgreSQL can not cast bit to boolean
        query = table.select(table.id,
            where=Operator(BAnd(table.synchronised_instances,
                    cls.synchronised_instances.sql_format(instance))
                != cls.synchronised_instances.sql_format(bitnull),
                cls.synchronised.sql_format(value)))
        return [('id', 'in', query)]

    @staticmethod
    def default_active():
        return True

    @classmethod
    def write(cls, records, values):
        if 'last_synchronisation' not in values:
            values['last_synchronisation'] = None
        return super(SyncMixin, cls).write(records, values)

    @classmethod
    def delete(cls, records):
        cls.write(records, {'active': False})

    def get_wire_value(self):
        values = {}
        for f_name, field in self._fields.items():
            if f_name in ('id', 'last_synchronisation',
                    'create_uid', 'write_uid'):
                continue
            if (isinstance(field, (fields.Function, fields.Many2Many,
                        fields.One2One, fields.One2Many))
                    and f_name != self.unique_id_column):
                continue
            value = getattr(self, f_name)
            values[f_name] = value
            if field._type == 'many2one':
                target = field.get_target()
                if issubclass(target, SyncMixin):
                    values[f_name] = (getattr(value, target.unique_id_column)
                        if value else None)
                else:
                    del values[f_name]
            if field._type == 'reference' and value:
                target = value.__class__
                if issubclass(target, SyncMixin):
                    values[f_name] = (target,
                        getattr(value, target.unique_id_column))
                else:
                    values[f_name] = None
        return values

    @classmethod
    def get_local_value(cls, values):
        pool = Pool()
        values = values.copy()

        def get_target_value(Target, unique_id):
            with Transaction().set_context(active_test=False):
                targets = Target.search([
                        (Target.unique_id_column, '=', unique_id),
                        ])
            if not targets:
                raise InexistantTarget(Target.__name__, unique_id)
            else:
                target, = targets
                return target

        for f_name in values:
            field = cls._fields[f_name]

            if field._type == 'many2one' and values[f_name]:
                Target = field.get_target()
                values[f_name] = get_target_value(Target, values[f_name]).id

            if field._type == 'reference' and values[f_name]:
                target, unique_id = values[f_name]
                Target = pool.get(target)
                values[f_name] = str(get_target_value(Target, unique_id))

        instances = values['synchronised_instances']
        my_instance = cls.default_synchronised_instances()
        new_instances = instances | my_instance
        if new_instances != values['synchronised_instances']:
            values['synchronised_instances'] = new_instances
        else:
            values['last_synchronisation'] = (values['write_date']
                or values['create_date'])
        return values

    @classmethod
    def synchronise_one(cls, value):
        local_records = cls.search([
                (cls.unique_id_column, '=', value[cls.unique_id_column])
                ])
        if not local_records:
            cls.create([cls.get_local_value(value)])
            return value[cls.unique_id_column]
        local_record, = local_records

        r_date = max(filter(None, (value['create_date'],
                    value['write_date'])))
        l_date = max(filter(None, (local_record.create_date,
                    local_record.write_date)))
        # Same date must also be synchronise to set the instances
        if l_date <= r_date:
            cls.write([local_record], cls.get_local_value(value))
        return value[cls.unique_id_column]

    @classmethod
    def synchronise(cls, values):
        synchronised, to_create = [], []
        DatabaseOperationalError = backend.get('DatabaseOperationalError')
        now = datetime.datetime.now()
        for value in values:
            with Transaction().new_cursor(), \
                    Transaction().set_user(0), \
                    Transaction().set_context(active_test=False) as t:
                retry = 0
                while retry < 2:
                    try:
                        synchronised_record = cls.synchronise_one(value)
                        t.cursor.commit()
                        synchronised.append(synchronised_record)
                    except DatabaseOperationalError:
                        retry += 1
                        continue
                    except (InexistantTarget, UserError):
                        pass
                    break

        return synchronised, now

    def get_etag(self):
        return (getattr(self, self.unique_id_column),
            self.write_date or self.create_date)

    @classmethod
    def get_to_synchronise(cls, remote_sync_data=None):
        unsynched = []
        with Transaction().set_context(active_test=False) as t:
            if remote_sync_data:
                in_max = t.cursor.IN_MAX
                for i in range(0, len(remote_sync_data), in_max):
                    unsync_domain = ['OR']
                    for unique_id, sync_date in remote_sync_data[i:i + in_max]:
                        unsync_domain.append([
                                (cls.unique_id_column, '=', unique_id),
                                ['OR', [('write_date', '!=', None),
                                        ('write_date', '>', sync_date)],
                                    [('write_date', '=', None),
                                        ('create_date', '>', sync_date)]]
                                ])
                    unsynched.extend(cls.search(unsync_domain))
            else:
                unsynched.extend(cls.search([
                            ('synchronised', '=', False),
                            ]))
        return [r.get_wire_value() for r in unsynched]

    @classmethod
    def to_synchronise_push(cls):
        with Transaction().set_context(active_test=False):
            return cls.search([
                    ('last_synchronisation', '=', None),
                    ])

    @classmethod
    def to_synchronise_pull(cls):
        with Transaction().set_context(active_test=False):
            return cls.search([])

    @classmethod
    def set_synchronised(cls, unique_ids, stamp):
        in_max = Transaction().cursor.IN_MAX
        records = []
        with Transaction().set_context(active_test=False):
            for i in xrange(0, len(unique_ids), in_max):
                records += cls.search([
                        (cls.unique_id_column, 'in', unique_ids[i:i + in_max]),
                        ])
        cls.write(records, {
                'last_synchronisation': stamp,
                })


class SyncUUIDMixin(SyncMixin):
    'Adds synchronisation support via UUID'

    unique_id_column = 'uuid'
    uuid = UUID('Universal Unique Identifier', required=True, select=True)

    @classmethod
    def __setup__(cls):
        super(SyncUUIDMixin, cls).__setup__()
        cls._sql_constraints += [
            ('uuid_unique', 'UNIQUE(uuid)', 'UUID must be unique.'),
            ]

    @staticmethod
    def default_uuid():
        return uuid.uuid4()
