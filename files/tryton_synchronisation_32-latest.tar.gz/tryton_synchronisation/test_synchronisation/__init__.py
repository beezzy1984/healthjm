# This file is part of tryton_synchronisation.  The COPYRIGHT file at the top
# level of this repository contains the full copyright notices and license
# terms.
from trytond.pool import Pool
from trytond.model import ModelSQL, ModelView, fields
from tryton_synchronisation import SyncUUIDMixin


def register():
    Pool.register(
        A,
        module='test_synchronisation', type_='model')


class A(SyncUUIDMixin, ModelSQL, ModelView):
    'A'
    __name__ = 'test_synchronisation.a'
    name = fields.Char('Name')
