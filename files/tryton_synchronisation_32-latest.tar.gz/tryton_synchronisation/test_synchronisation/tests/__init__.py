# This file is part of tryton_synchronisation.  The COPYRIGHT file at the top
# level of this repository contains the full copyright notices and license
# terms.
import unittest
import datetime

import bitstring

import trytond.tests.test_tryton as test_tryton
from trytond.tests.test_tryton import POOL, DB_NAME, USER, CONTEXT
from trytond.transaction import Transaction
from trytond.config import CONFIG


class SynchronisationTestCase(unittest.TestCase):
    'Test Synchronisation'

    def setUp(self):
        test_tryton.install_module('test_synchronisation')
        CONFIG['synchronisation_id'] = 0

    def tearDown(self):
        A = POOL.get('test_synchronisation.a')
        with Transaction().start(DB_NAME, USER, context=CONTEXT) as t:
            table = A.__table__()
            t.cursor.execute(*table.delete())
            t.cursor.commit()

    def test_uuid(self):
        'Test UUID'
        A = POOL.get('test_synchronisation.a')
        with Transaction().start(DB_NAME, USER, context=CONTEXT):
            a, = A.create([{'name': 'test'}])
            self.assert_(a.id)
            self.assert_(a.uuid)

    def test_synchronised(self):
        'Test UUID'
        A = POOL.get('test_synchronisation.a')
        with Transaction().start(DB_NAME, USER, context=CONTEXT):
            with Transaction().set_context(synchronisation_id=0):
                a, = A.create([{'name': 'test'}])
                self.assertTrue(a.synchronised)

            with Transaction().set_context(synchronisation_id=1):
                a, = A.search([])
                self.assertFalse(a.synchronised)

    def test_synchronise_push(self):
        'Test push synchronise'
        A = POOL.get('test_synchronisation.a')
        with Transaction().start(DB_NAME, USER, context=CONTEXT):
            a1, a2 = A.create([
                    {'name': 'test1'},
                    {'name': 'test2', 'last_synchronisation':
                        datetime.datetime.now()},
                    ])
            self.assertEqual(A.to_synchronise_push(), [a1])

            wire_value = {
                'name': u'test1',
                'create_date': a1.create_date,
                'write_date': None,
                'active': True,
                'uuid': a1.uuid,
                'synchronised_instances': a1.synchronised_instances,
                }
            self.assertEqual(a1.get_wire_value(), wire_value)
            # TODO test many2one and reference

            wire_value['name'] = 'test1 update'
            wire_value['write_date'] = datetime.datetime.now()
            other_instance = bitstring.BitArray(length=128)
            other_instance.set(1, 126)
            wire_value['synchronised_instances'] |= other_instance

            synchronised, stamp = A.synchronise([wire_value])
            self.assertEqual(synchronised, [a1.uuid])

            A.set_synchronised(synchronised, stamp)
            a1 = A(a1.id)
            self.assertEqual(a1.last_synchronisation, stamp)

    def test_synchronise_pull(self):
        'Test pull synchronise'
        A = POOL.get('test_synchronisation.a')
        with Transaction().start(DB_NAME, USER, context=CONTEXT):
            a1, a2 = A.create([
                    {'name': 'test1'},
                    {'name': 'test2'},
                    ])
            etags = [a1.get_etag(), a2.get_etag()]

            A.write([a1], {'name': 'test1 update'})

            to_synchronise = A.get_to_synchronise(etags)
            wire_value = {
                'name': u'test1 update',
                'create_date': a1.create_date,
                'write_date': a1.write_date,
                'active': True,
                'uuid': a1.uuid,
                'synchronised_instances': a1.synchronised_instances,
                }
            self.assertEqual(to_synchronise, [wire_value])

            A.synchronise(to_synchronise)

    def test_synchronise_new(self):
        'Test synchronise new'
        A = POOL.get('test_synchronisation.a')
        with Transaction().start(DB_NAME, USER, context=CONTEXT):
            synchronised_instances = bitstring.BitArray(length=128)
            synchronised_instances.set(1, 126)
            a1, a2 = A.create([
                    {'name': 'test1'},
                    {'name': 'test2',
                        'synchronised_instances': synchronised_instances},
                    ])

            with Transaction().set_context(synchronisation_id=0):
                to_synchronise = A.get_to_synchronise()

            wire_value = {
                'name': u'test2',
                'create_date': a2.create_date,
                'write_date': a2.write_date,
                'active': True,
                'uuid': a2.uuid,
                'synchronised_instances': a2.synchronised_instances,
                }
            self.assertEqual(to_synchronise, [wire_value])

            A.synchronise(to_synchronise)

            with Transaction().set_context(synchronisation_id=0):
                to_synchronise = A.get_to_synchronise()

            self.assertEqual(to_synchronise, [])

    def test_delete(self):
        'Test delete'
        A = POOL.get('test_synchronisation.a')
        with Transaction().start(DB_NAME, USER, context=CONTEXT):
            a, = A.create([{'name': 'test'}])
            self.assertEqual(a.active, True)
            A.delete([a])
            self.assertEqual(a.active, False)


def suite():
    suite = test_tryton.suite()
    suite.addTests(unittest.TestLoader().loadTestsFromTestCase(
            SynchronisationTestCase))
    return suite
