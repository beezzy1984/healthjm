# This file is part of tryton_synchronisation.  The COPYRIGHT file at the top
# level of this repository contains the full copyright notices and license
# terms.
import os
from setuptools import setup


def read(fname):
    return open(os.path.join(os.path.dirname(__file__), fname)).read()

setup(name='tryton_synchronisation',
    version='0.1',
    author='B2CK',
    author_email='info@b2ck.com',
    description='Adds record synchronisation support to Tryton',
    long_description=read('README'),
    py_modules=['tryton_synchronisation', 'celery_synchronisation'],
    packages=[
        'test_synchronisation',
        'test_synchronisation.tests',
        ],
    package_data={
        'test_synchronisation': ['tryton.cfg'],
        },
    zip_safe=False,
    platforms='any',
    classifiers=[
        'Environment :: Plugins',
        'Framework :: Tryton',
        'Intended Audience :: Developers',
        'License :: OSI Approved :: GNU General Public License (GPL)',
        'Operating System :: OS Independent',
        'Programming Language :: Python :: 2.7',
        'Topic :: Software Development :: Libraries :: Python Modules'
        ],
    license='GPL-3',
    install_requires=[
        'trytond>=3.0',
        'python-sql',
        'bitstring',
        'celery_tryton',
        ],
    extras_require={
        'PostgreSQL': ['psycopg2 >= 2.0.9'],
        },
    entry_points="""
    [trytond.modules]
    test_synchronisation = test_synchronisation
    """,
    test_suite='test_synchronisation.tests',
    test_loader='trytond.test_loader:Loader',
    )
